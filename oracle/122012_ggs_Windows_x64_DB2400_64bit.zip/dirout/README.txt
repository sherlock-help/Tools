This directory is not used any more.
