-- Copyright (c) 2005, 2012, Oracle and/or its affiliates. 
-- All rights reserved. 
-- chkpt_db2400_create.sql
--
-- DB2/400 Checkpoint Creation
--
-- Description:
-- Create the GGS_CHECKPOINT table.
--
-- Note: execute this script from the iSeries Navigator interactive SQL utility 
-- after a connection to the target database has been made.


DROP TABLE ggs_checkpoint;

COMMIT WORK;

CREATE TABLE ggs_checkpoint
(
    group_name        VARCHAR(8) NOT NULL,
    group_key         BIGINT NOT NULL,
    seqno             INTEGER,
    rba               BIGINT NOT NULL,
    audit_ts          VARCHAR(29),
    create_ts         TIMESTAMP NOT NULL,
    last_update_ts    TIMESTAMP NOT NULL,
    current_dir       VARCHAR(255) NOT NULL,
    log_bsn           VARCHAR(129),
    log_csn           VARCHAR(129),
    log_xid           VARCHAR(129),
    log_cmplt_csn     VARCHAR(129),
    log_cmplt_xids    VARCHAR(2000),
    version           INTEGER,
    PRIMARY KEY (group_name, group_key)
);

COMMIT WORK;

DROP TABLE ggs_checkpoint_lox;

COMMIT WORK;

CREATE TABLE ggs_checkpoint_lox
(
    group_name          VARCHAR(8) NOT NULL,
    group_key           BIGINT NOT NULL,
    log_cmplt_csn       VARCHAR(129) NOT NULL,
    log_cmplt_xids_seq  INTEGER NOT NULL,
    log_cmplt_xids      VARCHAR(2000) NOT NULL,
    PRIMARY KEY(group_name, group_key, log_cmplt_csn, log_cmplt_xids_seq)
);

COMMIT WORK;
