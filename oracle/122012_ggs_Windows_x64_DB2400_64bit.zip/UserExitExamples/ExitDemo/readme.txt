/ Copyright (C) 1995, 2010, Oracle and/or its affiliates. All rights reserved./


  User exit example for Windows NT and Unix.  This example uses the
  TCUSTMER and TCUSTORD tables, which can be created and manipulated using
  the demo*.sql scripts included with the ER release.


 To compile this exit code, use the appropriate make or project file in this same directory.  The compiles are 32bit,
 for 64bit, changes will be necessary in the make files as well as possibly #includes in the .c file.
