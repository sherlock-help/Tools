/**************************************************************************
 Copyright (c) 2001, 2015, Oracle and/or its affiliates. All rights reserved.

  Program description:

  Include file for user exit API.

  MODIFIED   (MM/DD/YY)
  lzheng      09/28/15 - XbranchMerge lzheng_bug-16616639 from main
  lzheng      07/23/15 - bug-16616639: add Unified Trail Format support to
                         userexit
  yoshbaba    03/10/15 - bug-20146445 added record event callback interface. incremented callback structure version to 4.
  yoshbaba    03/06/15 - bug-19690360 update all statistics fields to int64_t to match with core internal size.

  03/07/13 - ralekra
    Added comments in ddl_record_def

  01/18/13 - ralekra
   BUG-16176057 Add new callbacks for DDL metadata retrieval

  11/12/12 - jiexie
    bug-14613170: Added subdata types SQLSDT_XML to recognize the xml type
    
  02/26/12 - Yoshi
    Added AS/400 Native name member type to DB object type.

  04/20/12 - MYUIN - 1936926 - change some unnamed structs to named
  12/16/11 - GDW
    BUG 13502529 - Add numeric as string from Unicode tables subdata types

  08/15/11 - LZHENG
    add a new call type, EXIT_CALL_ABORT_TRANS
  07/11/11 - LZHENG
    add three new callback functions. bug 12684848. 
  04/15/11  
    g11n phase2 for userexit
  04/05/10 - RK
    OS-BUG-9417151: RFE:Support REPERROR TRANSDISCARD and Commit Error handling

  07/03/08 - TAS
    OS-6241
    Changed #ifdef for version function.

  06/25/08 - TAS
    OS-6241
    Added subdata types for metadata callbacks for GG data type identification.
    changed #ifdef for including version function

  04/22/08 - TAS
    FP 16239
    Added structures, callbacks and return codes for DDL and GETENV callbacks.

    FP 4162, 15738, 17880
    Modified record_def, column_def for PK updates before images.

    FP 15519, 17879, 17880
    Added logic to parse cuserexit params and set values.

    FP 17881
    Added num key cols to table_def.

    FP 17883
    Added versioning buffer logic.

    Added callback types GET_GGSENV_VALUE, GET_DDL_RECORD_PROPERTIES,
    RESET_STATS_TOTALS, GET_GMT_TIMESTAMP

    Added defines for datatype values.

  07/30/07 - TAS
    FP #15055
    Added structs for tokens and position call backs, versioning.

  03/22/07 - SMB
   Add support for column lengths up to 64K bytes.

  12/12/06 - TAS
    FP 13489, User Exit call backs for metadata stated in review 1104.

  11/30/06 - CP
    FP #13489
    Added callbacks GET_TABLE_METADATA and GET_COL_METADATA_FROM_INDEX and
    GET_COL_METADATA_FROM_NAME. Added structures col_meta_def and table_meta_def
    to support this change.

  10/06/06 - LH
    Added exit_col_buf_def[] type.

  06/16/06 - SMB
    FP #6797 - Large Row Support

  02/08/06 - SRC
    Support new callback functions:  FETCH_CURRENT_RECORD_WITH_LOCK,
    FETCH_CURRENT_RECORD, and OUTPUT_MESSAGE_TO_REPORT.  Fetching is only
    supported in replicat and only if a mapped target buffer is available.
    Fetch the current record by key from the target database.  Modify
    existing callbacks to expose the data values for the fetched record.
    Messages are output to the report file and/or console based on our
    existing reporting logic.

  04/01/03 - SRC
    Increase max internal record buffer size to SHRT_MAX bytes.

  03/19/03 - SRC
    Use int64_t instead of __int64.

  01/07/03 - SRC
    Don't define __int64 by default -- the customer can enable the typedef
    if necessary.

  09/20/02 - DAA
    Change BEFORE_IMAGE and AFTER_IMAGE to use numeric values instead of
    character literals - this helps avoid dependencies on ASCII that cause
    problems on non-ASCII systems.

  05/01/01 - SRC
    FP #2422.
    Initial revision.

***************************************************************************/

#ifndef USRDECS_H__
#define USRDECS_H__

#include <limits.h>
#include "ucharset.h"

#define CALLBACK_STRUCT_VERSION     4

#ifndef MAX_PATH
#define MAX_PATH 250
#endif

#ifndef MAX_REC_LEN
#define MAX_REC_LEN (512*1024)
#endif

#ifndef MAX_COL_LEN
#define MAX_COL_LEN (USHRT_MAX-32)
#endif

/* User exit parameters */
typedef short exit_call_type_def;
typedef short exit_result_def;

typedef char exit_rec_buf_def[MAX_REC_LEN];
typedef char exit_rec_buf_ascii_def[MAX_REC_LEN*2];

typedef char exit_col_buf_def[MAX_COL_LEN];
typedef char exit_col_buf_ascii_def[MAX_COL_LEN*2];

/* Timestamp string */
typedef char exit_ts_str[30];

/* User exit context */
typedef struct
{
    char program_name[MAX_PATH+1];
    char function_param[101];
    char more_recs_ind;
} exit_params_def;

/* User exit record types */
#define EXIT_REC_TYPE_SQL 1
#define EXIT_REC_TYPE_ENSCRIBE 2

/* User exit operation types */
#define DELETE_VAL                           3
#define INSERT_VAL                           5
#define UPDATE_VAL                          10
#define UPDATE_COMP_ENSCRIBE_VAL            11
#define UPDATE_COMP_SQL_VAL                 15
#define TRUNCATE_TABLE_VAL                 100
#define UPDATE_COMP_PK_SQL_VAL             115
#define UNIFIED_UPDATE_COMP_SQL_VAL        134
#define UNIFIED_UPDATE_COMP_PK_SQL_VAL     135
#define SQL_DDL_VAL                        160

/* User exit statistic groups */
#define EXIT_STAT_GROUP_STARTUP  1 /* Since process startup */
#define EXIT_STAT_GROUP_DAILY    2 /* Since midnight of the current day */
#define EXIT_STAT_GROUP_HOURLY   3 /* Since the start of the current hour */
#define EXIT_STAT_GROUP_RECENT   4 /* Since the last reset command via GGSCI */
#define EXIT_STAT_GROUP_REPORT   5 /* Since the last report was generated */
#define EXIT_STAT_GROUP_USEREXIT 6 /* Since the stats reset by user exit */

/* User exit return codes */
#define EXIT_OK_VAL             1 /* Extract or Replicat will continue to process */
#define EXIT_IGNORE_VAL         2 /* Extract or Replicat will skip this record */
#define EXIT_STOP_VAL           3 /* Extract or Replicat will STOP */
#define EXIT_ABEND_VAL          4 /* Extract or Replicat will ABEND */
#define EXIT_PROCESSED_REC_VAL  5 /* Extract or Replicat will skip this record, but update stats by Table by I/O type */

/* User exit OP codes */
#define EXIT_CALL_START                 1
#define EXIT_CALL_BEGIN_TRANS           2
#define EXIT_CALL_PROCESS_RECORD        3
#define EXIT_CALL_DISCARD_ASCII_RECORD  4
#define EXIT_CALL_DISCARD_RECORD        5
#define EXIT_CALL_END_TRANS             6
#define EXIT_CALL_CHECKPOINT            7
#define EXIT_CALL_PROCESS_MARKER        8
#define EXIT_CALL_STOP                  9
#define EXIT_CALL_DISCARD_TRANS_RECORD 10
#define EXIT_CALL_ABORT_TRANS          11
#define EXIT_CALL_EVENT_RECORD         12
#define EXIT_CALL_FATAL_ERROR          99

/* User exit return codes from callback routines */
#define EXIT_FN_RET_OK                      0
#define EXIT_FN_RET_INVALID_COLUMN          1
#define EXIT_FN_RET_COLUMN_NOT_FOUND        2
#define EXIT_FN_RET_TABLE_NOT_FOUND         3
#define EXIT_FN_RET_BAD_COLUMN_DATA         4
#define EXIT_FN_RET_INVALID_CONTEXT         5
#define EXIT_FN_RET_INVALID_PARAM           6
#define EXIT_FN_RET_INVALID_CALLBACK_FNC_CD 7
#define EXIT_FN_RET_NOT_SUPPORTED           8
#define EXIT_FN_RET_FETCH_ERROR             9
#define EXIT_FN_RET_EXCEEDED_MAX_LENGTH    10
#define EXIT_FN_RET_TOKEN_NOT_FOUND        11
#define EXIT_FN_RET_INVALID_RECORD_TYPE    12
#define EXIT_FN_RET_INCOMPLETE_DDL_REC     13
#define EXIT_FN_RET_ENV_NOT_FOUND          14
#define EXIT_FN_RET_INVALID_COLUMN_TYPE    15
#define EXIT_FN_RET_SESSION_CS_CNV_ERR     16
#define EXIT_FN_RET_BAD_DATE_TIME          17
#define EXIT_FN_RET_BAD_NUMERIC_VALUE      18
#define EXIT_FN_RET_NO_SRCDB_INSTANCE      19
#define EXIT_FN_RET_NO_TRTDB_INSTANCE      20

/* Old User exit ASCII/internal indicators - deprecated */
#define EXIT_FN_ASCII_FORMAT    1
#define EXIT_FN_INTERNAL_FORMAT 2

/* New User exit ASCII/internal indicators, starting from V3 */
#define EXIT_FN_CHAR_FORMAT    1
#define EXIT_FN_RAW_FORMAT 2
#define EXIT_FN_CNVTED_SESS_CHAR_FORMAT 3

/* User exit source/target indicators */
#define EXIT_FN_SOURCE_VAL  1
#define EXIT_FN_TARGET_VAL  2
#define EXIT_FN_CURRENT_VAL 3

/* User exit stop status codes */
#define STOP_STATUS_NORMAL 0
#define STOP_STATUS_ABEND  1

/* User exit transaction indicators */
#define BEGIN_TRANS_VAL  0
#define MIDDLE_TRANS_VAL 1
#define END_TRANS_VAL    2
#define WHOLE_TRANS_VAL  3

/* User exit before/after indicators */
#define BEFORE_IMAGE_VAL 0x42 /* ASCII B */
#define AFTER_IMAGE_VAL  0x41 /* ASCII A */

#define CHAR_YES_VAL 0x59   /* ASCII Y */
#define CHAR_NO_VAL  0x4e   /* ASCII N */

/* Position types  */
#define STARTUP_CHECKPOINT     0 /* starting position in the data source */
#define CURRENT_CHECKPOINT     1 /* position of last record read in the data source (CURRENT) */
#define RECOVERY_CHECKPOINT    2 /* Tranlog position of oldest unprocessed transaction in the data source -- FUTURE USE */

/* GG internal Data types */
#define SQLDT_ASCII_F       0
#define SQLDT_ASCII_F_UP    1
#define SQLDT_DOUBLE_F      2
#define SQLDT_ASCII_V      64
#define SQLDT_ASCII_V_UP   65
#define SQLDT_DOUBLE_V     66
#define SQLDT_16BIT_S     130
#define SQLDT_16BIT_U     131
#define SQLDT_32BIT_S     132
#define SQLDT_32BIT_U     133
#define SQLDT_64BIT_S     134
#define SQLDT_64BIT_U     135
#define SQLDT_REAL        140
#define SQLDT_DOUBLE      141
#define SQLDT_TDM_REAL    140
#define SQLDT_TDM_DOUBLE  141
#define SQLDT_IEEE_REAL   142
#define SQLDT_IEEE_DOUBLE 143
#define SQLDT_DEC_U       150
#define SQLDT_DEC_LSS     151
#define SQLDT_DEC_LSE     152
#define SQLDT_DEC_TSS     153
#define SQLDT_DEC_TSE     154
#define SQLDT_DEC_PACKED  155
#define SQLDT_DATETIME_V  191
#define SQLDT_DATETIME    192

/* Interval datatype */
/* Year to Year */
#define SQLDT_INT_Y_Y 195
/* Month to Month */
#define SQLDT_INT_MO_MO 196
/* Year to Month */
#define SQLDT_INT_Y_MO 197
/* Day to Day */
#define SQLDT_INT_D_D 198
/* Hour to Hour */
#define SQLDT_INT_H_H 199
/* Day to Hour */
#define SQLDT_INT_D_H 200
/* Minute to Minute */
#define SQLDT_INT_MI_MI 201
/* Hour to Minute */
#define SQLDT_INT_H_MI 202
/* Day to Minute */
#define SQLDT_INT_D_MI 203
/* Second to Second */
#define SQLDT_INT_S_S 204
/* Minute to Second */
#define SQLDT_INT_MI_S 205
/* Hour to Second */
#define SQLDT_INT_H_S 206
/* Day to Second */
#define SQLDT_INT_D_S 207
/* Fraction to Fraction */
#define SQLDT_INT_F_F 208
/* Second to Fraction */
#define SQLDT_INT_S_F 209
/* Minute to Fraction */
#define SQLDT_INT_MI_F 210
/* Hour to Fraction */
#define SQLDT_INT_H_F 211
/* Day to Fraction */
#define SQLDT_INT_D_F 212

/* GG internal Sub Data types */
#define SQLSDT_DEFAULT         0   /* Default value */
#define SQLSDT_UTF16_BE        1   /* UTF-16 big endian encoding */
#define SQLSDT_FLOAT           2   /* Floating-point number in string format */
#define SQLSDT_FLOAT_UTF8      27  /* Floating-point number in UTF8 format */
#define SQLSDT_FIXED_PREC      3   /* Fixed-precision number in string format */
#define SQLSDT_FIXED_PREC_UTF8 37  /* Fixed-precision number in UTF8 forat */
#define SQLSDT_BINARY          4   /* Binary data */
#define SQLSDT_CHAR_TYPE       5   /* CHAR datatype written with length info */
#define SQLSDT_MVS_ASCII       6   /* MVS ASCII encoding */
#define SQLSDT_UTF8            7   /* UTF-8 encoding */
#define SQLSDT_ASCII_GUID_LE   8   /* GUID string "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" */
#define SQLSDT_PERIOD          9   /* Period data type */
#define SQLSDT_XML             10  /* XML column */

/* Event record identifier */
#define EXIT_DATABASE_METADATA_EVENT      1   /* new or updated database metadata */
#define EXIT_TABLE_METADATA_EVENT         2   /* new or updated table metadata */
#define EXIT_REF_TABLE_METADATA_EVENT     3   /* new or updated ref-table metadata */

/* Callback function record definitions */
typedef struct
{
    char *column_value;                     /* Column value buffer */
    unsigned short max_value_length;        /* Maximum buffer length (max: MAX_COL_LEN) */
    unsigned short actual_value_length;     /* Actual buffer length (max: MAX_COL_LEN) */
    short null_value;                       /* Is the value NULL? */
    short remove_column;                    /* Remove this column from a compressed update? */
    short value_truncated;                  /* Was the value truncated? */
    short column_index;                     /* Column index */
    char *column_name;                      /* Column name */
    short column_value_mode;                /* changed from ascii_or_internal, from V3 */
    short source_or_target;                 /* Source or target value? */
   /* Version 2 CALLBACK_STRUCT_VERSION  */
    char requesting_before_after_ind;       /* request for the before or after image update indicator */
    char more_lob_data;                     /* continuation flag for more LOB chucks in memmory */
   /* Version 3 CALLBACK_STRUCT_VERSION   */
     ULibCharSet column_charset;            /* column character set */
} column_def;

typedef struct
{
    char *compressed_rec;   /* Compressed record */
    long compressed_len;    /* Compressed record length */
    char *decompressed_rec; /* Decompressed record */
    long decompressed_len;  /* Decompressed record length */
    short *columns_present; /* Columns present in compressed record */
    short source_or_target; /* Source or target record? */
   /* Version 2 CALLBACK_STRUCT_VERSION   */
    char requesting_before_after_ind;   /* request for the before or after image update indicator */
} compressed_rec_def;

typedef struct
{
    char *buffer;           /* Environment value buffer */
    long max_length;        /* Maximum buffer length */
    long actual_length;     /* Actual buffer length */
    short value_truncated;  /* Was value truncated? */
    short index;            /* Table or column index */
    short source_or_target; /* Source or target value? */
} env_value_def;

typedef struct
{
    char *information_type; /* Type of getenv wanted PASSED IN BY USER */
    char *env_value_name;   /* lable of getenv wanted PASSED IN BY USER */
    char *return_value;     /* return value of getenv */
    long max_return_length; /* Maximum buffer length */
    long actual_length;     /* Actual buffer length */
    short value_truncated;  /* Was value truncated? */
} getenv_value_def;

typedef struct
{
    long error_num;      /* SQL or system error number */
    char *error_msg;     /* Associated error message */
    long max_length;     /* Maximum error message length */
    long actual_length;  /* Actual error message length */
    short msg_truncated; /* Was error message truncated? */
} error_info_def;

typedef struct
{
    char *processed; /* Date/time marker processed in format 'YYYY-MM-DD HH:MI:SS' */
    char *added;     /* Date/time marker added in format 'YYYY-MM-DD HH:MI:SS' */
    char *text;      /* Marker text */
    char *group;     /* Group that processed marker */
    char *program;   /* Program that processed marker */
    char *node;      /* Originating node (Tandem) of marker */
} marker_info_def;

typedef struct record_def
{
    char *table_name;        /* Table name */
    char *buffer;            /* Record buffer */
    long length;             /* Record length */
    char before_after_ind;   /* Before/after indicator */
    short io_type;           /* Operation type */
    short record_type;       /* SQL or Enscribe? */
    short transaction_ind;   /* Transaction indicator */
    int64_t timestamp;       /* Operation timestamp */
    exit_ts_str io_datetime; /* Operation timestamp in format 'YYYY-MM-DD HH:MI:SS.FFFFFF' */
    short mapped;            /* Has the record been mapped? */
    short source_or_target;  /* Source or target record? */
   /* Version 2 CALLBACK_STRUCT_VERSION   */
    char requesting_before_after_ind;  /* request for the before or after image update indicator */
} record_def;

typedef struct statistics_def
{
    char *table_name;           /* Source table */
    short group;                /* Statistical group */
    exit_ts_str start_datetime; /* Statistics start time in format 'YYYY-MM-DD HH:MI:SS' */
    int64_t num_inserts;           /* Number of inserts since start of statistics */
    int64_t num_updates;           /* Number of updates since start of statistics */
    int64_t num_befores;           /* Number of before images since start of statistics */
    int64_t num_deletes;           /* Number of deletes since start of statistics */
    int64_t num_discards;          /* Number of discards since start of statistics */
    int64_t num_ignores;           /* Number of ignores since start of statistics */
    int64_t total_db_operations;   /* Total database operations since start of statistics */
    int64_t total_operations;      /* Total operations since start of statistics */
   /* Version 2 CALLBACK_STRUCT_VERSION   */
    int64_t num_truncates;         /* Number of truncates since start of statistics */
} statistics_def;


typedef struct
{
    char *table_name;          /* Table name */
    long  max_name_length;     /* Maximum table name length PASSED IN BY USER */
    short num_columns;         /* Number of columns in table */
    short num_key_columns;     /* Number of key columns in table */
    short *key_columns;        /* Array of key column indexes */
    short using_pseudo_key;    /* Did we create a pseudo key for a table with no unique key */
    short source_or_target;    /* Source or target table PASSED IN BY USER */
} table_metadata_def;

typedef struct
{
    short column_index;        /* Column index PASSED IN BY USER or column name passed in */
    char *column_name;         /* Column name  PASSED IN BY USER */
    long  max_name_length;     /* Max length of column_name field, PASSED IN BY USER */
    short native_data_type;    /* Native data type (Dependent on interface) */
    short gg_data_type;        /* Goldengate data type */
    short gg_sub_data_type;    /* Goldengate data sub type */
    short is_nullable;         /* Indicates if the column is nullable */
    short is_part_of_key;      /* Part of the primary key indicator */
    short key_column_index;    /* Indicates order of index of column in key */
    long length;               /* Column length */
    long precision;            /* ODBC precision */
    short scale;               /* Numeric scale */
    short source_or_target;    /* Source or target table? PASSED IN BY USER */
} col_metadata_def;

typedef struct
{
    short num_columns;      /* Number of columns in table */
    short source_or_target; /* Source or target table? */
   /* Version 2 CALLBACK_STRUCT_VERSION   */
    short num_key_columns;  /* number of key columns*/
} table_def;

typedef struct
{
    char *position;            /* currently string of 2 binary values unsigned int32t & int32t as seqnorba for 8 bytes */
    long position_len;         /* length of char */
    short position_type;       /* see defines above */
    short ascii_or_internal;   /* ASCII or internal format? */
} position_def;

typedef struct
{
    char *token_name;       /* Token Name as input to find value for PASSED IN BY USER*/
    char *token_value;      /* Token value buffer */
    long max_length;        /* Maximum Token Name length PASSED IN BY USER */
    long actual_length;     /* Actual buffer length */
    short value_truncated;  /* Was value truncated? */
} token_value_def;

typedef struct
{
    char *ddl_type;               /* Type of the DDL operation (e.g., CREATE, ALTER) */ 
    long ddl_type_max_length;     /* Maximum Description length PASSED IN BY USER */
    long ddl_type_length;         /* Actual length */
    
    char *object_type;            /* Type of object the DDL is operating on (e.g., TABLE, INDEX) */ 
    long object_type_max_length;  /* Maximum Description length PASSED IN BY USER */
    long object_type_length;      /* Actual length */

    char *object_name;            /* Fully qualified name of the object */ 
    long object_max_length;       /* Maximum Description length PASSED IN BY USER */
    long object_length;           /* Actual length */

    char *owner_name;             /* Owner of the object */ 
    long owner_max_length;        /* Maximum Description length PASSED IN BY USER */
    long owner_length;            /* Actual length */

    char *ddl_text;               /* DDL text */
    long ddl_text_max_length;     /* Maximum Description length PASSED IN BY USER */
    long ddl_text_length;         /* Actual length */
    short ddl_text_truncated;     /* Was value truncated? */

    short source_or_target;       /* Source or target value? */
} ddl_record_def;

/* event record: callback structure version 4 or later only */
typedef struct
{
    short  event_id;              /* event record identifier */
    char*  object_name;           /* object name of the event record (database or table) */
    long   max_name_length;       /* max length of object_name field, PASSED IN BY USER */
    long   actual_length;         /* actual object name length */
} event_record_def;

/* Callback function codes */
typedef enum
{
    COMPRESS_RECORD,                /* Compress the record buffer */
    DECOMPRESS_RECORD,              /* Decompress the record buffer */
    GET_BEFORE_AFTER_IND,           /* Return before/after indicator */
    GET_COLUMN_INDEX_FROM_NAME,     /* Return column index for a specified column name */
    GET_COLUMN_NAME_FROM_INDEX,     /* Return column name for a specified column index */
    GET_COLUMN_VALUE_FROM_INDEX,    /* Return column value for a specified column index */
    GET_COLUMN_VALUE_FROM_NAME,     /* Return column value for a specified column name */
    GET_ERROR_INFO,                 /* Return error information for a discard record */
    GET_MARKER_INFO,                /* Return marker information */
    GET_OPERATION_TYPE,             /* Return insert, update, or delete */
    GET_RECORD_BUFFER,              /* Return record buffer before or after mapping */
    GET_RECORD_LENGTH,              /* Return the record buffer length */
    GET_RECORD_TYPE,                /* Return the record type (SQL or Enscribe) */
    GET_STATISTICS,                 /* Return statistics for a specified statistical group */
    GET_TABLE_COLUMN_COUNT,         /* Return the number of columns in a table */
    GET_TABLE_NAME,                 /* Return the fully qualified table name */
    GET_TIMESTAMP,                  /* Return operation timestamp */
    GET_TRANSACTION_IND,            /* Return begin, middle, end, or whole */
    SET_COLUMN_VALUE_BY_INDEX,      /* Set a column value given a column index */
    SET_COLUMN_VALUE_BY_NAME,       /* Set a column value given a column name */
    SET_OPERATION_TYPE,             /* Set the operation type to insert, update, or delete */
    SET_RECORD_BUFFER,              /* Set the record buffer and length */
    SET_TABLE_NAME,                 /* Set the table name */
    FETCH_CURRENT_RECORD,           /* Fetch the current record given the target key */
    FETCH_CURRENT_RECORD_WITH_LOCK, /* Fetch and lock the current record given the target key */
    OUTPUT_MESSAGE_TO_REPORT,       /* Output a message to the report file. */
    GET_COL_METADATA_FROM_INDEX,    /* Returns Column detail information for a specified column index */
    GET_COL_METADATA_FROM_NAME,     /* Returns Column detail information for a specified column name */
    GET_TABLE_METADATA,             /* Returns basic table information */
    GET_POSITION,                   /* Returns position info */
    GET_USER_TOKEN_VALUE,           /* Returns User token value if present */
    GET_ENV_VALUE,                  /* Returns ENV values same as @GETENV */
    GET_DDL_RECORD_PROPERTIES,      /* Returns DDL text properties and DDL text */
    RESET_USEREXIT_STATS,           /* Resets All stats bucket totals for user exit interval */
    GET_GMT_TIMESTAMP,              /* Return operation timestamp in GMT */
    SET_SESSION_CHARSET,            /* Set session character set */
    GET_SESSION_CHARSET,            /* Get session character set */
    GET_DATABASE_METADATA,          /* Get database metadata */
    GET_TABLE_NAME_ONLY,            /* Return only the table name piece of the fully qualified table name */
    GET_SCHEMA_NAME_ONLY,           /* Return only the schema name piece of the full table name */
    GET_CATALOG_NAME_ONLY,          /* Return only the catalog name piece of the full table name */
    GET_OBJECT_NAME_ONLY,           /* Return only the object name piece of the fully qualified object name*/
    GET_OBJECT_NAME,                /* Return the fuly qualified object name */
    GET_BASE_OBJECT_NAME_ONLY,      /* Return only the base object name peice */
    GET_BASE_SCHEMA_NAME_ONLY,      /* Return only the schema name peice for the base object */
    GET_BASE_OBJECT_NAME,           /* Return the fuly qualified base object name */
    GET_EVENT_RECORD                /* Return the event record detail */
} ercallback_function_codes;


#ifndef _DBOBJTYPE_H_
# define _DBOBJTYPE_H_

/* Database object type enumuration. */
typedef enum
{
    DBGENERIC,             /* generic database object */

    DBTABLE,               /* table, NSK file */
    DBTABLESPACE,          /* tablespace */
    DBTRIGGER,             /* trigger */
    DBINDEX,               /* index */
    DBCONSTRAINT,          /* constraint */
    DBSEQUENCE,            /* sequence */

    DBSCHEMA,              /* schema, NSK sub-volume */
    DBCATALOG,             /* catalog/database, NSK disc */
    DBNODE,                /* NSK node */

    DBSERVER,              /* server */
    DBLOGIN,               /* login user */
    DBPASSWORD,            /* login password */

    DBCOLUMN,              /* column, can be A.B.C (e.g. UDT) */
    DBQUALSERVER,          /* fully qualified server name */

    DBMEMBER,              /* AS/400 member part. e.g. library/file(member) */

    MAXDBOBJTYPE           /* max, invalid. */
} DBObjType;

#endif

/* Callback function session character set definition */
typedef struct session_def
{
    ULibCharSet session_charset;   /* session character set */
} session_def;

/* Callback function database metadata definition */
/* it's better add the dbName_len, and local_len in the structure; 
   for eaiser use when session's character set is UTF16
 */
typedef struct
{
    char    *dbName;       /* database name */
    long dbName_max_length;      /* Maximum length dbName */
    long dbName_actual_length;   /* Actual dbName length */
    unsigned char dbNameMetadata[MAXDBOBJTYPE];  /* database object name metadata */
    char    *locale;       /* source database locale */
    long locale_max_length;      /* Maximum length dbName */
    long locale_actual_length;   /* Actual dbName length */
} database_def;

typedef struct database_defs
{
    database_def source_db_def;      /* source database metadata */
    database_def target_db_def;      /* target database metadata */
} database_defs;

/* 
 *    @brief    Database object name metadata bits.
 *  
 *    @detail   These bits are used to store and access database
 *    object name metadata.
 *  
 *    CS - Case Sensitive
 *    CI - Case Insensitive
 *    LC - Lower Case
 *    UC - Upper Case
 *    MIXED - Mixed Case
 */
enum
{
    /* unquoted name. */
    MIXED_CI_BIT               = 0x00,
    MIXED_CS_BIT               = 0x01,
    LC_CI_BIT                  = 0x02,
    UC_CI_BIT                  = 0x04,
    MIXED_CI_MASK              = 0x0f,
    MIXED_CI_UNSET_BITS        = 0xf0,

    /* quoted name. */
    MIXED_QUOTED_CI_BIT        = 0x00,
    MIXED_QUOTED_CS_BIT        = 0x10,
    LC_QUOTED_CI_BIT           = 0x20,
    UC_QUOTED_CI_BIT           = 0x40,
    MIXED_QUOTED_CI_MASK       = 0xf0,
    MIXED_QUOTED_CI_UNSET_BITS = 0x0f
};

/* 
 * Macros used to check database object name support for each data type 
 * Given a nameMeta, and DbObjType, we check if the object of the type 
 * support queried metadata
 */
/* 
 * check whether the db treats mixed case unquoted name for spedified data 
 * type as case sensitive and as result stores the name in mixed case.
 */
#define supportsMixedCaseIndentifiers( nameMeta, DbObjType )             \
    ((nameMeta[(int)DbObjType] & (uint8_t)(MIXED_CS_BIT)) != 0)  

/* 
 * check whether the db treats mixed case quoted name for spedified data 
 * type as case sensitive and as result stores the name in mixed case.
 */
#define supportsMixedCaseQuotedIndentifiers( nameMeta, DbObjType )       \
    ((nameMeta[(int)DbObjType] & (uint8_t)(MIXED_QUOTED_CS_BIT)) != 0)

/* 
 * check whether the db treats mixed case unquoted name for spedified data 
 * type as case sensitive and as result stores the name in lower case.
 */
#define storesLowerCaseIdentifiers( nameMeta, DbObjType )                \
    ((nameMeta[(int)DbObjType] & (uint8_t)(LC_CI_BIT)) != 0)  

/* 
 * check whether the db treats mixed case quoted name for spedified data 
 * type as case insensitive and as result stores the name in lower case.
 */
#define storesLowerCaseQuotedIdentifiers( nameMeta, DbObjType )          \
    ((nameMeta[(int)DbObjType] & (uint8_t)(LC_QUOTED_CI_BIT)) != 0)  

/* 
 * check whether the db treats mixed case unquoted name for spedified data 
 * type as case insensitive and as result stores the name in mixed case.
 */
#define storesMixedCaseIdentifiers( nameMeta, DbObjType )                \
    ((nameMeta[(int)DbObjType] & (uint8_t)(MIXED_CI_MASK)) == 0)  

/* 
 * check whether the db treats mixed case quoted name for spedified data 
 * type as case insensitive and as result stores the name in mixed case.
 */
#define storesMixedCaseQuotedIdentifiers( nameMeta, DbObjType )          \
    ((nameMeta[(int)DbObjType] & (uint8_t)(MIXED_QUOTED_CI_MASK)) == 0)  

/* 
 * check whether the db treats mixed case unquoted name for spedified data 
 * type as case insensitive and as result stores the name in upper case.
 */
#define storesUpperCaseIdentifiers( nameMeta, DbObjType )                \
    ((nameMeta[(int)DbObjType] & (UC_CI_BIT)) != 0)  

/* 
 * check whether the db treats mixed case quoted name for spedified data 
 * type as case insensitive and as result stores the name in upper case.
 */
#define storesUpperCaseQuotedIdentifiers( nameMeta, DbObjType )          \
    ((nameMeta[(int)DbObjType] & (UC_QUOTED_CI_BIT)) != 0)  

/* Structure versioning function Do Not Remove */
#if !(defined GOLDENGATE__)
  #if !(defined _WIN32)
     int (fperexitversion)(void)
     {
         return CALLBACK_STRUCT_VERSION;
     }
  #else
     __declspec(dllexport) int FPEREXITVERSION(void)
     {
         return CALLBACK_STRUCT_VERSION;
     }
  #endif
#endif


#endif /* USRDECS_H__ */
