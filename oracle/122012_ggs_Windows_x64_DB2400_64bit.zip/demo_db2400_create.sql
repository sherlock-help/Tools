-- Copyright (C) 2006, 2010, Oracle and/or its affiliates. All rights reserved.
-- 
-- demo_db2400_create.sql
--
-- DB2/400 Tutorial
--
-- Description:
-- Create the TCUSTMER and TCUSTORD tables.
--
-- Note: execute this script from the iSeries Navigator interactive SQL utility 
-- after a connection to the target database has been made.

CREATE TABLE tcustmer
(
    cust_code    VARCHAR(4)    NOT NULL,
    name         VARCHAR(30),
    city         VARCHAR(20),
    state        CHAR(2),
    PRIMARY KEY (cust_code)
);

COMMIT WORK;

CREATE TABLE tcustord
(
    cust_code         VARCHAR(4)    NOT NULL,
    order_date        TIMESTAMP     NOT NULL,
    product_code      VARCHAR(8)    NOT NULL,
    order_id          INTEGER       NOT NULL,
    product_price     DECIMAL(8,2),
    product_amount    INTEGER,
    transaction_id    FLOAT,
    PRIMARY KEY (cust_code, order_date, product_code, order_id)
);

COMMIT WORK;
